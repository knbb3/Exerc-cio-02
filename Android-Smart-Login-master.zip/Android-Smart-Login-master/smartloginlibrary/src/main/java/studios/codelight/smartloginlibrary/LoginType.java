package studios.codelight.smartloginlibrary;

/**
 * Copyright (c) 2017 Codelight Studios
 * Created by kalyandechiraju on 22/04/17.
 */

public enum LoginType {
    Facebook,
    Google,
    CustomLogin,
    CustomSignup
}
